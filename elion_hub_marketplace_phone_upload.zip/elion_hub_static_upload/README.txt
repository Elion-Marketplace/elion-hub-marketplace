ELION HUB MARKETPLACE - FRONTEND PREVIEW

This is a lightweight static prototype, not the full Django marketplace backend.
It demonstrates the storefront layout, sample products, search, category filtering, and demo cart.
Product listings and prices are illustrative. Login, vendor accounts, order processing, database storage, and real payments are not connected.

To publish with GitHub Pages:
1. Upload index.html to the root of your GitHub repository.
2. Commit the changes.
3. Open repository Settings > Pages.
4. Under Build and deployment, select Deploy from a branch.
5. Select branch main and folder /(root), then Save.
6. Wait for the public site URL to appear in Settings > Pages.
